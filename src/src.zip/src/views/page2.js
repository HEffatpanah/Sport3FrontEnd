import React, { Component } from 'react';

export default class Page2 extends Component {
    render() {
        return <p>adlkfjadsfjaldjfl;asdfjlasm</p>
    }
}