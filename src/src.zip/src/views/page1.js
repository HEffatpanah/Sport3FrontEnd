import React, { Component } from 'react';

export default class Page1 extends Component {
    render() {
        return <p>hello</p>
    }
}